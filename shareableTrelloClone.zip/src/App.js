import "./App.css";
import CardDetails from "./CardDetails";
import CreateCard from "./Card";
import React, { useState, useEffect } from "react";

function App({}) {
  const [cardData, setCardData] = useState([]);
  //state variable for cards to keep data for cards

  const addNewCard = (newCardInfo) => {
    console.log(newCardInfo);
    setCardData([...cardData, newCardInfo]);
  };

  const deleteCard = (index) => {
    const cardDataCopy = [...cardData];
    const cardToDelete = cardDataCopy.splice(index,1)
    setCardData(cardDataCopy)  
  }

  const editCard = (index,newCardToEdit) => {
    const cardEditData = [...cardData]
    cardEditData[index] = {...newCardToEdit}
    setCardData(newCardToEdit)
  }
  
  console.log(cardData);

  return (
    <div className="App">
      <nav className="navbar">App bar</nav>
      <nav className="board">Board</nav>
      <div className="board-columns">
        <div className="card-container">
          {cardData.map((card, index) => (
            <CardDetails card={card} erase={()=> deleteCard(index)} key={index} />
          ))}
          <CreateCard className="card" addNewCard={addNewCard} />
        </div>
      </div>
    </div>
  );
}

export default App;
