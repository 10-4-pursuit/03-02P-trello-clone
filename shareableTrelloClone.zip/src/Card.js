import React, { useEffect, useState } from "react";

function CreateCard({ addNewCard, editCard, card }) {
  const [newCardData, setNewCardData] = useState({
    title: "",
    description: "",
    label: "",
    dueDate: "",
    comment: "",
  });

  const onFormSubmit = (event) => {
    event.preventDefault();
    if (card) {
      editCard(newCardData);
    } else {
      addNewCard(newCardData);
    }

    setNewCardData({
      title: "",
      description: "",
      label: "",
      dueDate: "",
      comment: "",
    });
  };

  const updateCardInfo = (key, value) => {
    setNewCardData((prev) => ({ ...prev, [key]: value }));
  };

  useEffect(() => {
    const newValues = card || {
      title: "",
      description: "",
      label: "",
      dueDate: "",
      comment: "",
    };
    setNewCardData(newValues);
  }, [card]);

  return (
    <form onSubmit={onFormSubmit}>
      <div className="cardForm">
        <input
          type="text"
          value={newCardData.title}
          onChange={(e) => updateCardInfo("title", e.target.value)}
          placeholder="Enter a title for the card"
        ></input>
        <textarea
          value={newCardData.description}
          onChange={(e) => updateCardInfo("description", e.target.value)}
          placeholder="Description"
        ></textarea>

        <select
          name="label"
          id="label"
          value={newCardData.label}
          onChange={(e) => updateCardInfo("label", e.target.value)}
        >
          <option value="placeholder">Choose an option</option>
          <option value="Urgent">Urgent</option>
          <option value="High Priority">High Priority</option>
          <option value="Medium Priority">Medium Priority</option>
          <option value="Low Priority">Low Priority</option>
          <option value="Optional">Optional</option>
        </select>
        <label for="dueDate"> Choose Due Date</label>
        <input
          type="date"
          id="dueDate"
          value={newCardData.dueDate}
          onChange={(e) => updateCardInfo("dueDate", e.target.value)}
          placeholder="Choose Due Date"
        ></input>
        <textarea
          value={newCardData.comment}
          onChange={(e) => updateCardInfo("comment", e.target.value)}
          placeholder="Enter comments"
        ></textarea>
        <button type="submit">Add Card</button>
      </div>
    </form>
  );
}

export default CreateCard;
