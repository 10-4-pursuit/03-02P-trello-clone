import React, { useState } from "react";

// const
// function CreateList() {
//   const [addList, setAddList] = useState(false);
//   const [title, setTitle] = useState("");
//   const [lists, setLists] = useState([]);//this list state is an array where each element 
//   //represents a list. whenever we add a neww list the array is updated.
  

//   const onButtonClick = () => {
//     setAddList(true);
  
//   };

//   const confirmInput = (event) => {
//     if (event.key === "Enter") {
//       console.log(title);
//       setAddList(false);
//     }
//   };

//   return (
//     <div>
//       {addList ? (
//         <input
//           type="text"
//           placeholder="Enter a title for this list..."
//           value={title}
//           onChange={(event) => setTitle(event.target.value)}
//           onKeyPress={confirmInput}
//           autoFocus
//         />
//       ) : (
//         <button onClick={onButtonClick}>Add a list</button>
//       )}

//     </div>
//   );
// }

// export default CreateList;