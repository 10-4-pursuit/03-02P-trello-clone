const CardDetails = ({ card, erase }) => {
  
  
    return (
    <div className="card">
      <p>{card.title}</p>
      <p>{card.description}</p>
      <p>{card.label}</p>
      <p>{card.dueDate}</p>
      <p>{card.comment}</p>
      <button type="submit" onClick={erase}>Delete Card</button>
      <button type="submit">Edit Card</button>
    </div>
  );
};

export default CardDetails;
